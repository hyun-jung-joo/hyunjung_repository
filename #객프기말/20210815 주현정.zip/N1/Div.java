
public class Div extends Calc{
	Div(int x, int y) {
		super(x, y);
	}

	public int calculate() {
		return x / y;
	}
}
