
public class Add extends Calc{
	
	Add(int x, int y) {
		super(x, y);
	}
	
	public int calculate() {
		return x + y;
	}
}
