
public class Mul extends Calc{
	public int calculate() {
		return x * y;
	}
	
	Mul(int x, int y) {
		super(x, y);
	}
}
