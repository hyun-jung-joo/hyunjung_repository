
public class Sub extends Calc{
	public int calculate() {
		return x - y;
	}
	
	Sub(int x, int y) {
		super(x, y);
	}
}
