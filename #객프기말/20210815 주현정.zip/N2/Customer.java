
public class Customer implements Discountable{
	int price;
	
	Customer(int price) {
		this.price = price;
	}
	
	public void discount() {
		
	}
}
