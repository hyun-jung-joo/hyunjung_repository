
public interface Delivery {
	int getTotalPrice();
}
